"""Experimental arrival-time-consistent observed wind-profile guidance.

The existing profile planner converts an offset predicted at one estimated
horizon into an effective constant velocity. Its beam search then evaluates
other arrival times with that velocity. This isolated variant instead asks the
same observation-only profile for an offset at each candidate's own arrival
time. No simulator state, seed, or unreleased balloon is used by the policy.
"""

import numpy as np

from BalloonPoppingGymEnv.agents.scenario4_pure_joint_refresh_agent import (
    Scenario4PureJointRefreshAgent,
)
from BalloonPoppingGymEnv.agents.time_allocation_agent import TimeAllocationAgent


class Scenario4HorizonProfileAgent(Scenario4PureJointRefreshAgent):
    def __init__(self, given_parameters, **kwargs):
        super().__init__(given_parameters, **kwargs)
        self._horizon_context = None
        self.diagnostics.update(horizon_profile_plans=0,
                                horizon_profile_corrections=0)

    def _forecast_positions(self, states, indices, horizons):
        centers = super()._forecast_positions(states, indices, horizons)
        context = self._horizon_context
        if context is None:
            return centers
        status, position, cache = context
        for row, (index, horizon) in enumerate(zip(indices, horizons)):
            index = int(index)
            horizon = float(horizon)
            if (status[index] != 1 or not 0 < horizon <= self.profile_horizon or
                    np.linalg.norm(states[index, :3] - position) >
                    self.profile_max_range):
                continue
            key = (index, round(horizon, 6))
            if key not in cache:
                cache[key] = self.wind_profile.correction(
                    states, status, index, horizon)
                if np.any(cache[key]):
                    self.diagnostics["horizon_profile_corrections"] += 1
            centers[row, :2] += self.profile_blend * cache[key]
        return centers

    def _make_plan(self, observation, position, velocity, now):
        states = np.asarray(observation["balloon_states"], dtype=float)
        status = np.asarray(observation["balloon_status"]).reshape(-1)
        self._horizon_context = (status, np.asarray(position, dtype=float), {})
        try:
            # Bypass only Scenario4WindProfileAgent's one-horizon pseudo-
            # velocity substitution. The beam search, timing solver, final
            # approach guard, and joint rescue still run as before.
            return TimeAllocationAgent._make_plan(
                self, observation, position, velocity, now)
        finally:
            if any(np.any(v) for v in self._horizon_context[2].values()):
                self.diagnostics["horizon_profile_plans"] += 1
            self._horizon_context = None
