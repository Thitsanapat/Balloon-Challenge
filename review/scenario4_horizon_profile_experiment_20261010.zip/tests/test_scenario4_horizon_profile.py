"""Arrival-specific wind forecast remains observation-only and bounded."""

import unittest

import numpy as np

from BalloonPoppingGymEnv.agents.scenario4_horizon_profile_agent import (
    Scenario4HorizonProfileAgent,
)
from BalloonPoppingGymEnv.agents.scenario4_wind_profile_agent import (
    ObservedWindProfile,
)


class HorizonProfileTests(unittest.TestCase):
    def test_linear_shear_uses_each_arrival_horizon(self):
        z = np.array([80., 85., 90., 95., 100., 105., 110., 115., 120.])
        states = np.zeros((len(z), 6))
        states[:, 2] = z
        states[:, 3] = 2.0 + .1 * (z - 100.)
        states[:, 5] = 5.0
        agent = Scenario4HorizonProfileAgent.__new__(Scenario4HorizonProfileAgent)
        agent.profile_horizon = 8.0
        agent.profile_max_range = 150.0
        agent.profile_blend = 1.0
        agent.wind_profile = ObservedWindProfile()
        agent.diagnostics = {"horizon_profile_corrections": 0}
        agent._horizon_context = (np.ones(len(z), dtype=int),
                                  np.array([0., 0., 100.]), {})
        predicted = agent._forecast_positions(states, (4, 4), (1., 2.))
        # The 0.1 m/s/m shear and 5 m/s rise induce 0.5 m/s^2 drift
        # acceleration, hence offsets 0.25 m and 1.0 m respectively.
        np.testing.assert_allclose(predicted[:, 0], [2.25, 5.0], atol=1e-8)
        self.assertEqual(agent.diagnostics["horizon_profile_corrections"], 2)

    def test_no_context_preserves_constant_velocity_default(self):
        states = np.zeros((2, 6))
        states[:, 0] = [1., 3.]
        states[:, 3] = [2., 4.]
        agent = Scenario4HorizonProfileAgent.__new__(Scenario4HorizonProfileAgent)
        agent._horizon_context = None
        predicted = agent._forecast_positions(states, (0, 1), (2., 3.))
        np.testing.assert_allclose(predicted[:, 0], [5., 15.])


if __name__ == "__main__":
    unittest.main()
